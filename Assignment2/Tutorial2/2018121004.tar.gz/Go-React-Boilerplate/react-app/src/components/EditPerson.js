import React, { Component } from 'react';
import './EditPerson.css';

class EditPerson extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">Edit a Person</h1>
        </header>
      </div>
    );
  }
}

export default EditPerson;
